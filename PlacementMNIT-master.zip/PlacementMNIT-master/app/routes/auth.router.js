const router = require('express').Router();

// todo get all authentication stuff over here
module.exports = router;
